import { NextApiRequest, NextApiResponse } from "next";
import { getSession } from "next-auth/react";
import { db } from "~/server/db";
import { supabase } from "~/utils";


export default async function handler(req: NextApiRequest, res: NextApiResponse)    {
    const session = await getSession({ req });

    if (!session)   {
        return res.status(401).json({ status: 401, error: "Not authorized" });
    }
    return res.status(200).json({ status: 200, message: `Logged in as ${session.user.name}` });
}


// export default async function handler(req: NextApiRequest, res: NextApiResponse)    {
//     const session = await getSession({ req });
//     console.log(session);

//     const { userID } = req.query;

//     if (!session)   {
//         return res.status(401).json({ status: 401, error: "Not Authorized" });
//     }

//     if (req.method !== 'POST')  {
//         return res.status(405).json({ status: 405, error: "Method not allowed" });
//     }

//     if (session.user.id !== userID) {
//         return res.status(401).json({ status: 401, error: "Not Authorized" });
//     }

//     const { path, file }: { path: string, file: File } = req.body;

//     const up = await supabase.storage.from('silicodrive').upload(`${session.user.id}${path}/${file.name}`, file);

//     if (up.error)   {
//         return res.status(500).json({ status: 500, message: "Internal error" });
//     }

//     const status = await db.file.create({
//         data: {
//             name: file.name,
//             owner: session.user.id,
//             path: path,
//             type: 0,
//             url: up.data.fullPath,
//             visibility: 0
//         }
//     });

//     return res.status(200).json({ status: 200, message: `File uploaded successfully to path ${path}` });
// }